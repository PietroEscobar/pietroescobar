# Parte 1 — Teoria: Encapsulamento

## 1. O que é encapsulamento?
Encapsulamento é proteger os dados de uma classe, controlando como eles podem ser acessados ou alterados por meio de métodos.

- `public`: pode ser acessado de qualquer lugar.
- `protected`: pode ser acessado pela própria classe e por suas classes filhas.
- `private`: só pode ser acessado dentro da própria classe.

Não é uma boa prática deixar todos os atributos como `public`, porque qualquer parte do código poderia alterar os dados sem controle, causando valores inválidos e dificultando a manutenção.

## 2. Para que servem os métodos get e set?
- O método `get` permite consultar o valor de um atributo privado.
- O método `set` permite alterar o valor de um atributo privado de maneira controlada.
- Um `set` também pode validar o valor antes de salvar.

Exemplo: `setIdade($valor)` pode verificar se a idade é maior ou igual a zero. Se for inválida, não salva o valor.

## 3. Verdadeiro ou falso — encapsulamento
1. **Falso.** Um atributo `private` não pode ser lido diretamente fora da classe.
2. **Falso.** Getters e setters também podem ser usados com outros níveis de acesso, embora sejam comuns com atributos `private`.
3. **Verdadeiro.** O encapsulamento protege os dados e facilita a manutenção do código.
4. **Verdadeiro.** É possível ter um getter sem setter quando o atributo pode ser consultado, mas não deve ser alterado externamente.
