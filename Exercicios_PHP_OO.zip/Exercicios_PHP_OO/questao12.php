<?php
class Funcionario {
    private $nome;
    private $cargo;
    private $salario;

    public function __construct($nome, $cargo, $salario) {
        $this->nome = $nome;
        $this->cargo = $cargo;
        $this->salario = $salario;
    }

    public function getNome() { return $this->nome; }
    public function getCargo() { return $this->cargo; }
    public function getSalario() { return $this->salario; }

    public function aumentarSalario($percentual) {
        if ($percentual > 0) {
            $this->salario = $this->salario * (1 + $percentual / 100);
        }
    }

    public function exibir() {
        echo 'Nome: ' . $this->nome . PHP_EOL;
        echo 'Cargo: ' . $this->cargo . PHP_EOL;
        echo 'Salario: R$ ' . number_format($this->salario, 2, ',', '.') . PHP_EOL . PHP_EOL;
    }
}

$funcionario = new Funcionario('Joao', 'Analista', 2500);
echo "Antes do aumento:" . PHP_EOL;
$funcionario->exibir();

$funcionario->aumentarSalario(15);
echo "Depois do aumento:" . PHP_EOL;
$funcionario->exibir();
?>
