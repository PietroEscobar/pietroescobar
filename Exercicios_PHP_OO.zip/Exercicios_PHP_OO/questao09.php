<?php
class ContaBancaria {
    private $titular;
    private $saldo;

    public function __construct($titular) {
        $this->titular = $titular;
        $this->saldo = 0;
    }

    public function depositar($valor) {
        if ($valor <= 0) {
            echo "Valor de deposito invalido." . PHP_EOL;
            return;
        }
        $this->saldo += $valor;
    }

    public function sacar($valor) {
        if ($valor <= 0) {
            echo "Valor de saque invalido." . PHP_EOL;
            return;
        }
        if ($valor > $this->saldo) {
            echo "Saldo insuficiente." . PHP_EOL;
            return;
        }
        $this->saldo -= $valor;
    }

    public function getSaldo() { return $this->saldo; }
    public function getTitular() { return $this->titular; }
}

$conta = new ContaBancaria('Maria');
$conta->depositar(500);
$conta->sacar(200);

echo 'Titular: ' . $conta->getTitular() . PHP_EOL;
echo 'Saldo final: R$ ' . number_format($conta->getSaldo(), 2, ',', '.') . PHP_EOL;
?>
