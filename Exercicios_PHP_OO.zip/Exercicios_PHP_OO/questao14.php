<?php
class Estoque {
    private $produtos = [];

    public function adicionarProduto($nome, $quantidade) {
        $this->produtos[] = [
            'nome' => $nome,
            'qtd' => $quantidade
        ];
    }

    public function listarProdutos() {
        foreach ($this->produtos as $produto) {
            echo $produto['nome'] . ': ' . $produto['qtd'] . PHP_EOL;
        }
    }

    public function totalItens() {
        $total = 0;
        foreach ($this->produtos as $produto) {
            $total += $produto['qtd'];
        }
        return $total;
    }
}

$estoque = new Estoque();
$estoque->adicionarProduto('Teclado', 5);
$estoque->adicionarProduto('Mouse', 10);
$estoque->adicionarProduto('Monitor', 3);

echo "Produtos em estoque:" . PHP_EOL;
$estoque->listarProdutos();
echo 'Total de itens: ' . $estoque->totalItens() . PHP_EOL;
?>
