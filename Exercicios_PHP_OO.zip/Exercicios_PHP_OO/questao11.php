<?php
class Retangulo {
    private $largura;
    private $altura;

    public function __construct($largura, $altura) {
        $this->setLargura($largura);
        $this->setAltura($altura);
    }

    public function getLargura() { return $this->largura; }
    public function setLargura($largura) {
        if ($largura > 0) {
            $this->largura = $largura;
        }
    }

    public function getAltura() { return $this->altura; }
    public function setAltura($altura) {
        if ($altura > 0) {
            $this->altura = $altura;
        }
    }

    public function calcularArea() {
        return $this->largura * $this->altura;
    }

    public function calcularPerimetro() {
        return 2 * ($this->largura + $this->altura);
    }
}

$r1 = new Retangulo(5, 3);
$r2 = new Retangulo(4, 4);

echo 'Area do retangulo 1: ' . $r1->calcularArea() . PHP_EOL;
echo 'Area do retangulo 2: ' . $r2->calcularArea() . PHP_EOL;

if ($r1->calcularArea() > $r2->calcularArea()) {
    echo 'O retangulo 1 tem maior area.' . PHP_EOL;
} elseif ($r2->calcularArea() > $r1->calcularArea()) {
    echo 'O retangulo 2 tem maior area.' . PHP_EOL;
} else {
    echo 'Os dois retangulos tem a mesma area.' . PHP_EOL;
}
?>
