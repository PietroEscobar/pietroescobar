<?php
// Erro: faltou usar a palavra-chave new para instanciar o objeto.
// Correção: utilizar new Carro(...).

class Carro {
    private $modelo;

    public function __construct($modelo) {
        $this->modelo = $modelo;
    }

    public function getModelo() {
        return $this->modelo;
    }
}

$c = new Carro('Fusca');
echo $c->getModelo();
?>
