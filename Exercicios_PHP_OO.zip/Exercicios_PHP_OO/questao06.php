<?php
// Erro: o código avisava que a idade era inválida, mas mesmo assim a salvava.
// Correção: usar return para impedir a atribuição de um valor inválido.

class Pessoa {
    private $idade;

    public function setIdade($idade) {
        if ($idade < 0) {
            echo 'Idade invalida!';
            return;
        }

        $this->idade = $idade;
    }

    public function getIdade() {
        return $this->idade;
    }
}

$p = new Pessoa();
$p->setIdade(-5);
?>
