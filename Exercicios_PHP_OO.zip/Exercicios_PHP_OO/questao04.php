<?php
// Erro: tentar acessar diretamente um atributo private fora da classe.
// Correção: criar e utilizar um getter.

class Produto {
    private $nome;
    private $preco;

    public function __construct($nome, $preco) {
        $this->nome = $nome;
        $this->preco = $preco;
    }

    public function getNome() {
        return $this->nome;
    }
}

$p = new Produto('Teclado', 150.00);
echo $p->getNome();
?>
